
 <!-- Header -->
 <header class="header">
    <div class="header-nav">
      <div class="header-nav-wrapper navbar-scrolltofixed bg-silver-light">
        <div class="container">
          <nav id="menuzord-right" class="menuzord default no-bg">
              <a class="menuzord-brand pull-left flip" href="<?php echo e(url('')); ?>"><img src="<?php echo e(asset('public/images/GAIN_LOGO.png')); ?>" alt=""></a>
            <ul class="menuzord-menu">
              <li class="active"><a href="<?php echo e(url('')); ?>">Home</a></li>
              <li><a href="<?php echo e(url('/about')); ?>">About</a></li>
              <li><a href="<?php echo e(url('/career')); ?>">Carrer</a></li>
              <li><a href="<?php echo e(url('/contact')); ?>">Contact Us</a></li>
              <li><a href="#">Refference</a>
                  <ul class="dropdown">
                      <li><a href="#">Payment Methods</a></li>
                      <li><a href="#">API Documentations</a></li>
                      <li><a href="#">FAQ</a></li>
                      <li><a href="#">Site Statistic</a></li>
                      <li><a href="#">Sitemap</a></li>
                  </ul>
              </li>
              <li><a href="#">News</a></li>
              <li><a href="#">Referral Programs</a></li>
            </ul>
          </nav>
        </div>
      </div>
    </div>
  </header>
<!-- end Header --><?php /**PATH C:\xampp\htdocs\new_gainmax\resources\views/layouts/menu.blade.php ENDPATH**/ ?>