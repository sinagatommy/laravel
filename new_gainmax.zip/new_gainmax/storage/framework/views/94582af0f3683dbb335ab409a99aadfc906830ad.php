<!-- Footer -->
  <footer id="footer" class="footer" data-bg-img="<?php echo e(('public/images/footer-bg.png')); ?>" data-bg-color="#25272e">
    <div class="container pt-70 pb-40">
        
      <div class="row">
        <div class="col-sm-6 col-md-3">
          <div class="widget dark">
            <ul class="list angle-double-right">
              <li><a href="#">About Us</a></li>
              <li><a href="#">Investment</a></li>
              <li><a href="#">Why Us?</a></li>
              <li><a href="#">Contact Us</a></li>              
            </ul>
          </div>
        </div>
          
        <div class="col-sm-6 col-md-3">
          <div class="widget dark">
            <ul class="list angle-double-right">
              <li><a href="#">API Documentations</a></li>
              <li><a href="#">Knowledge Base</a></li>
              <li><a href="#">FAQ</a></li>
              <li><a href="#">Support</a></li>              
            </ul>
          </div>
        </div>
          
        <div class="col-sm-6 col-md-3">
          <div class="widget dark">
            <ul class="list angle-double-right">
              <li><a href="#">Payment Method</a></li>
              <li><a href="#">System Status</a></li>
              <li><a href="#">Term & Conditions</a></li>
              <li><a href="#">Privacy Policy</a></li>              
            </ul>
          </div>
        </div>
          
          <div class="col-sm-6 col-md-3">
              <div class="widget dark">
                    <ul class="styled-icons icon-dark icon-theme-colored icon-circled icon-sm">
                      <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                      <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                      <li><a href="#"><i class="fa fa-youtube"></i></a></li>
                      <li><a href="#"><i class="fa fa-instagram"></i></a></li>
                    </ul>
              </div>
              <div class="widget dark">
                  <ul>
                      <li><a href="#"><img src="<?php echo e(('public/images/download_apple.png')); ?>" alt=""></a></li>
                      <li><a href="#"><img src="<?php echo e(('public/images/download_google.png')); ?>" alt=""></a></li>
                  </ul>
              </div>
          </div>
      </div>
        
      <div class="row">
          <div class="col-sm-6 col-md-3">
              <div class="widget dark mb-0">
                  <img class="mt-10 mb-20" alt="" src="<?php echo e(asset('public/images/gain_dark_bottom.png')); ?>">
              </div>
          </div>
          
      </div>
      <div class="row">
              <div class="col-sm-6 col-md-12">
                  <p class="line-bottom">Copyright ©2017 GainMax Capital Limited. All Rights Reserved.</p>
                <p>GainMax Capital Limited is an Financial Company registered in UNITED KINGDOM, number 10829908. Any reference to the advisory services refers to GainMax Capital Limited<br/>
                    Any copying, reproduction, republication, as well as on the Internet resources of any materials from www.gainmax.co.uk is possible only upon written permission.</p>
          </div>
      </div>
        
    </div>
    
  </footer><?php /**PATH C:\xampp\htdocs\new_gainmax\resources\views/layouts/footer.blade.php ENDPATH**/ ?>