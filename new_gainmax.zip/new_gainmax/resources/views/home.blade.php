<!DOCTYPE html>
<html dir="ltr" lang="en">
<head>

<!-- Meta Tags -->
<meta name="viewport" content="width=device-width,initial-scale=1.0"/>
<meta http-equiv="content-type" content="text/html; charset=UTF-8"/>
<meta name="description" content="FundPro - Nonprofit, Crowdfunding & Charity HTML5 Template" />
<meta name="keywords" content="charity,crowdfunding,nonprofit,orphan,Poor,funding,fundrising,ngo,children" />
<meta name="author" content="ThemeMascot" />

<!-- Page Title -->
<title>FundPro - Nonprofit, Crowdfunding & Charity HTML5 Template</title>
<!-- masa yang seperti ini bisa muncul (assets/images/favicon.png) -->
<!-- Favicon and Touch Icons -->
<link href="{{ asset('public/images/favicon.png') }}" rel="shortcut icon" type="image/png">
<link href="{{ asset('public/images/apple-touch-icon.png') }}" rel="apple-touch-icon">
<link href="{{ asset('public/images/apple-touch-icon-72x72.png') }}" rel="apple-touch-icon" sizes="72x72">
<link href="{{ asset('public/images/apple-touch-icon-114x114.png') }}" rel="apple-touch-icon" sizes="114x114">
<link href="{{ asset('public/images/apple-touch-icon-144x144.png') }}" rel="apple-touch-icon" sizes="144x144">

<!-- Stylesheet -->
<link href="{{ asset('public/css/bootstrap.min.css') }}" rel="stylesheet" type="text/css">
<link href="{{ asset('public/css/jquery-ui.min.css') }}" rel="stylesheet" type="text/css">
<link href="{{ asset('public/css/animate.css" rel="stylesheet') }}" type="text/css">
<link href="{{ asset('public/css/css-plugin-collections.css') }}" rel="stylesheet"/>
<!-- CSS | menuzord megamenu skins -->
<link id="menuzord-menu-skins" href="{{ asset('public/assets/css/menuzord-skins/menuzord-rounded-boxed.css') }}" rel="stylesheet"/>
<!-- CSS | Main style file -->
<link href="{{ asset('public/css/style-main.css') }}" rel="stylesheet" type="text/css">
<!-- CSS | Preloader Styles -->
<link href="{{ asset('public/css/preloader.css') }}" rel="stylesheet') }}" type="text/css">
<!-- CSS | Custom Margin Padding Collection -->
<link href="{{ asset('public/css/custom-bootstrap-margin-padding.css') }}" rel="stylesheet" type="text/css">
<!-- CSS | Responsive media queries -->
<link href="{{ asset('public/css/responsive.css') }}" rel="stylesheet" type="text/css">
<!-- CSS | Style css. This is the file where you can place your own custom css code. Just uncomment it and use it. -->
<!-- <link href="css/style.css" rel="stylesheet" type="text/css"> -->

<!-- Revolution Slider 5.x CSS settings -->
<link  href="{{ asset('public/js/revolution-slider/css/settings.css') }}" rel="stylesheet" type="text/css"/>
<link  href="{{ asset('public/js/revolution-slider/css/layers.css') }}" rel="stylesheet" type="text/css"/>
<link  href="{{ asset('public/js/revolution-slider/css/navigation.css') }}" rel="stylesheet" type="text/css"/>

<!-- CSS | Theme Color -->
<link href="{{ asset('public/css/theme-skin-gainmax.css') }}" rel="stylesheet" type="text/css">

<!-- external javascripts -->
<script type="text/javascript" src="{{ asset('public/js/jquery-2.2.4.min.js') }}"></script>
<script src="{{ asset('public/js/jquery-ui.min.js') }}"></script>
<script src="{{ asset('public/js/bootstrap.min.js') }}"></script>
<!-- JS | jquery plugin collection for this theme -->
<script src="{{ asset('public/js/jquery-plugin-collection.js') }}"></script>

<!-- Revolution Slider 5.x SCRIPTS -->
<script type="text/javascript" src="{{ asset('public/js/revolution-slider/js/jquery.themepunch.tools.min.js') }}"></script>
<script type="text/javascript" src="{{ asset('public/js/revolution-slider/js/jquery.themepunch.revolution.min.js') }}"></script>

<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
<!--[if lt IE 9]>
  <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
<![endif]-->
</head>
<body class="">
<div id="wrapper" class="clearfix">
  <!-- preloader -->
  <div id="preloader">
    <div id="spinner">
      <div class="preloader-dot-loading">
        <div class="cssload-loading"><i></i><i></i><i></i><i></i></div>
      </div>
    </div>
    <div id="disable-preloader" class="btn btn-default btn-sm">Disable Preloader</div>
  </div> 

  @include('layouts.menu')

  <!-- Start main-content -->
  <div class="main-content">
  
    <!-- Section: home -->
    <section id="home" class="divider">
      <div class="fullwidth-carousel" data-nav="true">
        <div class="carousel-item bg-img-cover" data-bg-img="{{ ('public/images/image-bank/bg_1.jpeg') }}">
          <div class="display-table layer-overlay overlay-dark-4">
            <div class="display-table-cell">
              <div class="container pt-200 pb-200">
                <div class="row">
                  <div class="col-md-12">
                    <h1 class="text-white text-uppercase font-60 mb-0">Save a <span class="text-theme-colored">Child</span></h1>
                    <h4 class="text-white font-weight-400 mt-0">Every day we bring hope to millions of children in the world's <br>hardest places as a sign of God's unconditional love.</h4>
                    <a class="btn btn-colored btn-theme-colored btn-flat smooth-scroll-to-target mt-20" href="#donate-now">Read More</a>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="carousel-item bg-img-cover" data-bg-img="{{ ('public/images/image-bank/photo_1.jpeg') }}">
          <div class="display-table layer-overlay overlay-dark-4">
            <div class="display-table-cell">
              <div class="container pt-200 pb-200">
                <div class="row">
                  <div class="col-md-12">
                    <h1 class="text-white text-uppercase font-60 mb-0">Save a <span class="text-theme-colored">Child</span></h1>
                    <h4 class="text-white font-weight-400 mt-0">Every day we bring hope to millions of children in the world's <br>hardest places as a sign of God's unconditional love.</h4>
                    <a class="btn btn-colored btn-theme-colored btn-flat smooth-scroll-to-target mt-20" href="#donate-now">Read More</a>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="carousel-item bg-img-cover" data-bg-img="{{ ('public/images/image-bank/photo_2.jpeg') }}">
          <div class="display-table layer-overlay overlay-dark-4">
            <div class="display-table-cell">
              <div class="container pt-200 pb-200">
                <div class="row">
                  <div class="col-md-12">
                    <h1 class="text-white text-uppercase font-60 mb-0">Save a <span class="text-theme-colored">Child</span></h1>
                    <h4 class="text-white font-weight-400 mt-0">Every day we bring hope to millions of children in the world's <br>hardest places as a sign of God's unconditional love.</h4>
                    <a class="btn btn-colored btn-theme-colored btn-flat smooth-scroll-to-target mt-20" href="#donate-now">Read More</a>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>

    <!-- Section: home-box -->
    <section class="bg-silver-light">
      <div class="container">
        <div class="section-content">
          <div class="row mt-sm-0">
            <div class="col-sm-6 col-md-4">
              <div class="causes bg-white border-1px border-bottom-theme-color-1px clearfix mb-0">
                <div class="col-md-5 col-lg-5 p-0">
                  <div class="thumb">
                    <img class="img-fullwidth" alt="" src="{{ ('public/images/image-bank/photo_1.jpeg') }}">
                  </div>
                </div>
                <div class="col-md-7 col-lg-7 p-0">
                  <div class="causes clearfix p-20 pt-15">
                    <h3 class="mt-0"><a class="text-theme-colored" href="#">Stock</a></h3>
                    <p class="pt-0">Profit Return</p>
                    <div class="progress-item mt-0">
                      <div class="progress mb-0">
                        <div data-percent="24" class="progress-bar"><span class="percent">0</span></div>
                      </div>
                    </div>
                    <p class="mt-15 mb-0">(+24%) per month</p>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-sm-6 col-md-4">
              <div class="causes bg-white border-1px border-bottom-theme-color-1px clearfix mb-0">
                <div class="col-md-5 col-lg-5 p-0">
                  <div class="thumb">
                    <img class="img-fullwidth" alt="" src="{{ ('public/images/image-bank/photo_1.jpeg') }}">
                  </div>
                </div>
                <div class="col-md-7 col-lg-7 p-0">
                  <div class="causes clearfix p-20 pt-15">
                    <h3 class="mt-0"><a class="text-theme-colored" href="#">Currencies</a></h3>
                    <p class="pt-0">Profit Return</p>
                    <div class="progress-item mt-0">
                      <div class="progress mb-0">
                        <div data-percent="26" class="progress-bar"><span class="percent">0</span></div>
                      </div>
                    </div>
                    <p class="mt-15 mb-0">(+24%) per month</p>
                  </div>
                </div>
              </div>
            </div>
              <div class="col-sm-6 col-md-4">
              <div class="causes bg-white border-1px border-bottom-theme-color-1px clearfix mb-0">
                <div class="col-md-5 col-lg-5 p-0">
                  <div class="thumb">
                    <img class="img-fullwidth" alt="" src="{{ ('public/images/image-bank/photo_1.jpeg') }}">
                  </div>
                </div>
                <div class="col-md-7 col-lg-7 p-0">
                  <div class="causes clearfix p-20 pt-15">
                    <h3 class="mt-0"><a class="text-theme-colored" href="#">Commodities</a></h3>
                    <p class="pt-0">Profit Return</p>
                    <div class="progress-item mt-0">
                      <div class="progress mb-0">
                        <div data-percent="18" class="progress-bar"><span class="percent">0</span></div>
                      </div>
                    </div>
                    <p class="mt-15 mb-0">(+24%) per month</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
            
            <div class="row text-center">
                <div class="col-md-10 col-md-offset-1">
                    <p class="mb-0 mt-30">
                        DATA FROM GAINMAX RESEARCH 02/05/2018, 11:29:05 AM.<br/>
                        PAST PERFORMANCE IS NOT AN INDICATION OF FUTURES RESULTS.
                    </p>
                </div>
            </div>
            
        </div>
      </div>
    </section>

    <section class="divider parallax layer-overlay overlay-dark-7" data-bg-img="{{ ('public/images/image-bank/bg_1.jpeg') }}">
      <div class="container pt-40 pb-40">
        <div class="row">
          <div class="">
            <div class="col-md-6 text-center">
              <iframe width="560" height="315" src="https://www.youtube.com/embed/9GZc8r-JNBA" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe>
            </div>
            <div class="col-md-6 text-left text-white">
              <h2 class="mt-0 text-white">Relax start earning shared revenue</h2>
              <h4 class="text-white">Work with us the way you want.</h4>
              <p>Investing in the world's most popular financial market has never been easier. GainMax Capital Limited is the trading company that provides total trading solutions that help you achieve trading success and improve your chances of getting residual income</p>
              <!--a href="#" class="btn btn-theme-colored btn-circled mt-20">Read More</a-->
            </div>
          </div>
        </div>
      </div>
    </section>
    
    <section class="bg-theme-colored">
      <div class="container pt-0 pb-0">
        <div class="row">
          <div class="col-md-12">
            <div class="call-to-action pt-30 pb-30">
              <div class="col-md-9">
                <h3 class="text-white">Open your account</h3>
                <p class="text-white">Connect with over 5 millions investors in the world’s leading social investment network</p>
              </div>
              <div class="col-md-3 text-right sm-text-center mt-20"> 
                <a href="#" class="btn btn-transparent btn-border btn-circled btn-lg mt-10">Create Account</a> 
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    
    <!-- Divider: Testimonials -->
    <section class="divider parallax layer-overlay overlay-dark-9" data-bg-img="{{ ('public/images/image-bank/bg_2.jpeg') }}">
      <div class="container">
        <div class="section-title text-center">
          <div class="row">
            <div class="col-md-8 col-md-offset-2">
              <h2 class="text-white mt-0">Testimonials</h2>
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-md-12">
            <div class="owl-carousel-3col testimonials" data-dots="true">
              <div class="item">
                <div class="testimonial-wrapper text-center">
                    <div class="thumb"><img class="img-circle" alt="" src="{{ ('public/images/image-bank/photo_1.jpeg') }}"></div>
                  <div class="content pt-10">
                    <p class="font-14 text-white mb-30">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Neque est quasi, quas ipsam, expedita placeat facilis odio illo ex accusantium eaque itaque officiis et sit. Vero quo, impedit neque.</p>
                    <i class="fa fa-quote-right"></i>
                    <h4 class="author text-theme-colored mb-0">Catherine Grace</h4>
                    <h6 class="title text-gray-lightgray mt-0 mb-15">Designer</h6>
                  </div>
                </div>
              </div>
              <div class="item">
                <div class="testimonial-wrapper text-center">
                  <div class="thumb"><img class="img-circle" alt="" src="{{ ('public/images/image-bank/photo_1.jpeg') }}"></div>
                  <div class="content pt-10">
                    <p class="font-14 text-white mb-30">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Neque est quasi, quas ipsam, expedita placeat facilis odio illo ex accusantium eaque itaque officiis et sit. Vero quo, impedit neque.</p>
                    <i class="fa fa-quote-right"></i>
                    <h4 class="author text-theme-colored mb-0">Catherine Grace</h4>
                    <h6 class="title text-gray-lightgray mt-0 mb-15">Designer</h6>
                  </div>
                </div>
              </div>
              <div class="item">
                <div class="testimonial-wrapper text-center">
                  <div class="thumb"><img class="img-circle" alt="" src="{{ ('public/images/image-bank/photo_1.jpeg') }}"></div>
                  <div class="content pt-10">
                    <p class="font-14 text-white mb-30">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Neque est quasi, quas ipsam, expedita placeat facilis odio illo ex accusantium eaque itaque officiis et sit. Vero quo, impedit neque.</p>
                    <i class="fa fa-quote-right"></i>
                    <h4 class="author text-theme-colored mb-0">Catherine Grace</h4>
                    <h6 class="title text-gray-lightgray mt-0 mb-15">Designer</h6>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    
    <!-- Section: Services -->
    <section id="services">
      <div class="container">
        <div class="section-title text-center">
          <div class="row">
            <div class="col-md-10 col-md-offset-1">
              <h2 class="text-uppercase mt-0 line-height-1">MANY WAYS TO INVEST, ONE PLACE TO DO IT.</h2>
            </div>
          </div>
        </div>
        <div class="section-content">
          <div class="row">
            <div class="col-xs-12 col-sm-6 col-md-3 col-lg-3">
              <div class="text-center mb-30 p-30">
                <a href="#" class="">
                  <img src="{{ ('public/images/flaticon-png/small/7.png') }}" width="70" alt="">
                </a>
                <h4 class="font-weight-600 mt-20">AVAILABLE FOR EVERYONE</h4>
                <p>GainMax available for everyone "anyone and anywhere", Investment starting from $10"</p>
              </div>
            </div>
            <div class="col-xs-12 col-sm-6 col-md-3 col-lg-3">
              <div class="text-center mb-30 p-30">
                <a href="#" class="">
                  <img src="{{ ('public/images/flaticon-png/small/3.png') }}" width="70" alt="">
                </a>
                <h4 class="font-weight-600 mt-20">SIMPLE, SECURE & PROFITABLE</h4>
                <p>All you just need to do is register, deposit and relax as you start earning shared revenue.</p>
              </div>
            </div>
            <div class="col-xs-12 col-sm-6 col-md-3 col-lg-3">
              <div class="text-center mb-30 p-30">
                <a href="#" class="">
                  <img src="{{ ('public/images/flaticon-png/small/2.png') }}" width="70" alt="">
                </a>
                <h4 class="font-weight-600 mt-20">HIGH GAIN & STRESS FREE</h4>
                <p>We offer simple, easy, secure and stress-free investing experience</p>
              </div>
            </div>
            <div class="col-xs-12 col-sm-6 col-md-3 col-lg-3">
              <div class="text-center mb-30 p-30">
                <a href="#" class="">
                  <img src="{{ ('public/images/flaticon-png/small/7.png') }}" width="70" alt="">
                </a>
                <h4 class="font-weight-600 mt-20">24/5 EXCELLENT SUPPORT</h4>
                <p>Our client support team is available to assist you 24 hours a day, 5 days a week</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  </div>
    @extends('layouts.footer')
  <a class="scrollToTop" href="#"><i class="fa fa-angle-up"></i></a>
</div>
<!-- end wrapper -->

<!-- Footer Scripts -->
<!-- JS | Custom script for all pages -->
<script src="{{ ('public/js/custom.js') }}"></script>

<!-- SLIDER REVOLUTION 5.0 EXTENSIONS  
      (Load Extensions only on Local File Systems ! 
       The following part can be removed on Server for On Demand Loading) -->
<script type="text/javascript" src="{{ asset('public/js/revolution-slider/js/extensions/revolution.extension.carousel.min.js') }}"></script>
<script type="text/javascript" src="{{ asset('public/js/revolution-slider/js/extensions/revolution.extension.kenburn.min.js') }}"></script>
<script type="text/javascript" src="{{ asset('public/js/revolution-slider/js/extensions/revolution.extension.layeranimation.min.js') }}"></script>
<script type="text/javascript" src="{{ asset('public/js/revolution-slider/js/extensions/revolution.extension.migration.min.js') }}"></script>
<script type="text/javascript" src="{{ asset('public/js/revolution-slider/js/extensions/revolution.extension.navigation.min.js') }}"></script>
<script type="text/javascript" src="{{ asset('public/js/revolution-slider/js/extensions/revolution.extension.parallax.min.js') }}"></script>
<script type="text/javascript" src="{{ asset('public/js/revolution-slider/js/extensions/revolution.extension.slideanims.min.js') }}"></script>
<script type="text/javascript" src="{{ asset('public/js/revolution-slider/js/extensions/revolution.extension.video.min.js') }}"></script>

</body>
</html>